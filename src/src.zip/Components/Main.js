function Main() {
    return(
        <div>
            Главная
        </div>
    )
}

export default Main;