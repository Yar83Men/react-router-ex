function Blog() {
    return(
        <div>
            Блог
        </div>
    )
}

export default Blog;