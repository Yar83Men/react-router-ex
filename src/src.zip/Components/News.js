function News() {
    return(
        <div>
            Новости
        </div>
    )
}

export default News;